package com.rizkym.authreqres.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.recyclerview.widget.LinearLayoutManager
import com.rizkym.authreqres.R
import com.rizkym.authreqres.adapter.LoadingStateAdapter
import com.rizkym.authreqres.adapter.UserListAdapter
import com.rizkym.authreqres.auth.LoginActivity
import com.rizkym.authreqres.databinding.ActivityMainBinding
import com.rizkym.authreqres.utils.UserPreferences
import com.rizkym.authreqres.utils.ViewModelFactory

// Initialize DataStore as an extension property
private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_key")

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val userListAdapter = UserListAdapter()

    // Use viewModels delegate with a custom factory
    private val mainViewModel: MainViewModel by viewModels {
        ViewModelFactory(
            application,  // Pass the application instance
            UserPreferences.getInstance(dataStore)  // Pass UserPreferences instance
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        setupRecyclerView()
        observeViewModel()
    }

    private fun setupRecyclerView() {
        binding.rvUser.layoutManager = LinearLayoutManager(this)
        val adapter = UserListAdapter()
        binding.rvUser.adapter = adapter.withLoadStateFooter(
            footer = LoadingStateAdapter { adapter.retry() }
        )
    }

    private fun observeViewModel() {
        mainViewModel.user.observe(this) { pagingData ->
            userListAdapter.submitData(lifecycle, pagingData)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.option_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_logout -> {
                mainViewModel.logout()
                startActivity(Intent(this, LoginActivity::class.java))
                Toast.makeText(this, getString(R.string.logout_alert), Toast.LENGTH_SHORT).show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
