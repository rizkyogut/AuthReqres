package com.rizkym.authreqres.utils

import android.app.Application
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.rizkym.authreqres.ui.MainViewModel
import com.rizkym.authreqres.auth.LoginViewModel
import com.rizkym.authreqres.di.Injection

class ViewModelFactory(private val context: Context, private val preferences: UserPreferences) :
    ViewModelProvider.NewInstanceFactory() {
    private lateinit var mApplication: Application

    fun setApplication(application: Application) {
        mApplication = application
    }

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(LoginViewModel::class.java)) {
            return LoginViewModel(preferences) as T
        }
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            return MainViewModel(Injection.provideRepository(context), preferences) as T
        } else throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
    }
}