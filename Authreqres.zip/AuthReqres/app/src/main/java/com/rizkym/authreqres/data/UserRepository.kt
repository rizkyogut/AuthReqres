package com.rizkym.authreqres.data

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.paging.*
import com.rizkym.authreqres.database.UserDatabase
import com.rizkym.authreqres.remote.config.ApiService
import com.rizkym.authreqres.remote.response.UserResponseItem

class UserRepository(private val userDatabase: UserDatabase, private val apiService: ApiService): ViewModel() {
    fun getPagingUsers(): LiveData<PagingData<UserResponseItem>> {
        @OptIn(ExperimentalPagingApi::class)
        return Pager(
            config = PagingConfig(
                pageSize = 6
            ),
            remoteMediator = UserRemoteMediator(userDatabase, apiService),
            pagingSourceFactory = {
                userDatabase.userDao().getAllUser()
            }
        ).liveData
    }
}